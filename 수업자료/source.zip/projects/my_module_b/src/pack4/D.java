package pack4;

public class D {
	//메소드
	public void method() {
		System.out.println("D-method 실행");
	}
}