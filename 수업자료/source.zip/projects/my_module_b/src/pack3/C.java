package pack3;

public class C {
	//메소드
	public void method() {
		System.out.println("C-method 실행");
	}
}