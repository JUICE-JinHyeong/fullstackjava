package ch07.sec07.exam02;

public class Parent {
	//메소드 선언
	public void method1() {
		System.out.println("Parent-method1()");
	}

	//메소드 선언
	public void method2() {
		System.out.println("Parent-method2()");
	}
}