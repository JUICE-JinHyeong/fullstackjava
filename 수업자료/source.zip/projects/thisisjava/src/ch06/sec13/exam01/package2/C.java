package ch06.sec13.exam01.package2;
	
import ch06.sec13.exam01.package1.*;
	
public class C {
	//필드 선언
	//A a; //x
	B b;   //o
}