package ch06.sec04;

public class Student {
}