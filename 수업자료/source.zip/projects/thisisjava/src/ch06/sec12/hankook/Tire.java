package ch06.sec12.hankook;

public class Tire {
}