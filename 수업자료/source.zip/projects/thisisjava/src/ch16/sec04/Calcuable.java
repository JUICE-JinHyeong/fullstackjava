package ch16.sec04;

@FunctionalInterface
public interface Calcuable {
	double calc(double x, double y);
}