package ch08.sec10.exam01;

public class B implements A {
}