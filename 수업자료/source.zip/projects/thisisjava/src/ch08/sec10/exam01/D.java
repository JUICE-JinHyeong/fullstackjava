package ch08.sec10.exam01;

public class D extends B {
}