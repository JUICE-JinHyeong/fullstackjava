package ch08.sec10.exam02;

public interface Vehicle {
	//추상 메소드
	void run();
}