package ch08.sec13;

public non-sealed interface InterfaceB extends InterfaceA {
	void methodB();
}