package ch08.sec07;

public class ServiceImpl implements Service {
}