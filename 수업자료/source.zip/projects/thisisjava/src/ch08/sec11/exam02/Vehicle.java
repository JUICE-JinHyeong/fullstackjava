package ch08.sec11.exam02;

public interface Vehicle {
	//추상 메소드
	void run();
}