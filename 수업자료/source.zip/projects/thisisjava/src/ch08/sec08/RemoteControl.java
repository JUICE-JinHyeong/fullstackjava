package ch08.sec08;

public interface RemoteControl {
	//추상 메소드
	void turnOn();
	void turnOff();
}