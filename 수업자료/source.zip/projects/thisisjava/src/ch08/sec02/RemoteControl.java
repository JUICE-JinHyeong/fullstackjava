package ch08.sec02;

public interface RemoteControl {
	//public 추상 메소드
	public void turnOn();
}	