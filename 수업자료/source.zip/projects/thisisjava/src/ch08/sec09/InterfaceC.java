package ch08.sec09;

public interface InterfaceC extends InterfaceA, InterfaceB {
	//추상 메소드
	void methodC();
}