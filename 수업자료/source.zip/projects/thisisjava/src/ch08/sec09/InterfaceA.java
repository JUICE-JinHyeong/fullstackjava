package ch08.sec09;

public interface InterfaceA {
	//추상 메소드
	void methodA();
}