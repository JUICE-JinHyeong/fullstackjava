package ch08.sec09;

public interface InterfaceB {
	//추상 메소드
	void methodB();
}