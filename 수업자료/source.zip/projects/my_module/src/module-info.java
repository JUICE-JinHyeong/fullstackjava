module my_module {
	requires transitive my_module_a;
	requires transitive my_module_b;	
}