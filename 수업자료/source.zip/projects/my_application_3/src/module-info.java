module my_application_3 {
	requires my_module_a;
	requires my_module_b;	
}