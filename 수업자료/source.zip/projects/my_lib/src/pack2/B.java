package pack2;

public class B {
	//메소드
	public void method() {
		System.out.println("B-method 실행");
	}
}