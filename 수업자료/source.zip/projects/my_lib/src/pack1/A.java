package pack1;

public class A {
	//메소드
	public void method() {
		System.out.println("A-method 실행");
	}
}